package com.snhu.sslserver;

import java.security.MessageDigest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

}
//FIXME: Add route to enable check sum return of static data example:  String data = "Hello World Check Sum!";
@RestController
class ServerController{    
    @RequestMapping("/hash")
    public String myHash(){
    	String data = "Hello Timothy Johnson!";
    	String algorithm = "SHA-256";
    	String hash = generateChecksum(data, algorithm);
    	
    	return "<p>data: " + data + "<br>Algorithm: " + algorithm + "<br>Checksum Value: " + hash + "</p>";
    }
    private String generateChecksum(String data, String algorithm) {
    	try {
            MessageDigest md = MessageDigest.getInstance(algorithm);
            byte[] hashBytes = md.digest(data.getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (byte b : hashBytes) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (Exception e) {
            return null;
        }
    }
}